
/**
 * LocalFlow Signaling Server
 * -------------------------
 * Run this on one computer in the LAN: node server.js
 * It will act as the discovery hub for all instances of the web app.
 *
 * Requirements: npm install express socket.io
 */

/*
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});

const peers = new Map();

io.on('connection', (socket) => {
  const ip = socket.handshake.address;
  console.log(`New peer connected: ${socket.id} from ${ip}`);

  socket.on('register', (data) => {
    peers.set(socket.id, {
      id: socket.id,
      name: data.name,
      ip: ip,
      status: 'online'
    });
    // Broadcast updated list to everyone
    io.emit('peers-update', Array.from(peers.values()));
  });

  socket.on('disconnect', () => {
    peers.delete(socket.id);
    io.emit('peers-update', Array.from(peers.values()));
    console.log(`Peer disconnected: ${socket.id}`);
  });

  // WebRTC Signaling
  socket.on('signal', (data) => {
    io.to(data.to).emit('signal', {
      from: socket.id,
      signal: data.signal
    });
  });
});

const PORT = 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`LocalFlow Server running on http://0.0.0.0:${PORT}`);
  console.log(`Users can now find each other on the local network.`);
});
*/
