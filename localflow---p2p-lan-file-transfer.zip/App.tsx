
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Peer, TransferProgress, ThrottlingLimit, TransferSummary } from './types';
import Sidebar from './components/Sidebar';
import SendPanel from './components/SendPanel';
import ReceiversPanel from './components/ReceiversPanel';
import HistoryPanel from './components/HistoryPanel';
import Modal from './components/Modal';
import { TransferService } from './services/transferService';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'send' | 'receivers' | 'history'>('send');
  const [peers, setPeers] = useState<Peer[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [selectedPeer, setSelectedPeer] = useState<Peer | null>(null);
  const [currentTransfer, setCurrentTransfer] = useState<TransferProgress | null>(null);
  const [throttle, setThrottle] = useState<ThrottlingLimit>(0);
  const [showSummary, setShowSummary] = useState<TransferSummary | null>(null);
  const [deviceName, setDeviceName] = useState(`Device-${Math.floor(Math.random() * 1000)}`);

  const transferServiceRef = useRef<TransferService | null>(null);

  useEffect(() => {
    // Initialize our p2p service
    const service = new TransferService(deviceName);
    transferServiceRef.current = service;

    service.onPeersUpdate = (updatedPeers) => {
      setPeers(updatedPeers);
    };

    service.onTransferProgress = (progress) => {
      setCurrentTransfer(progress);
      if (progress.status === 'completed') {
        const duration = ((Date.now() - (progress.startTime || Date.now())) / 1000).toFixed(1);
        setShowSummary({
          fileName: progress.fileName,
          fileSize: (progress.fileSize / (1024 * 1024)).toFixed(2) + ' MB',
          duration: `${duration}s`,
          status: 'success'
        });
        setCurrentTransfer(null);
      }
      if (progress.status === 'failed') {
        setShowSummary({
          fileName: progress.fileName,
          fileSize: (progress.fileSize / (1024 * 1024)).toFixed(2) + ' MB',
          duration: 'N/A',
          status: 'error'
        });
      }
    };

    service.init();

    return () => {
      service.destroy();
    };
  }, [deviceName]);

  const handleScan = useCallback(async () => {
    setIsScanning(true);
    if (transferServiceRef.current) {
      await transferServiceRef.current.scan();
    }
    setTimeout(() => setIsScanning(false), 1500);
  }, []);

  const handleSendFile = async (file: File, peerId: string) => {
    if (transferServiceRef.current) {
      transferServiceRef.current.setThrottling(throttle);
      await transferServiceRef.current.sendFile(file, peerId);
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 overflow-y-auto p-8 relative">
        <header className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-slate-800">LocalFlow</h1>
            <p className="text-slate-500 mt-1">Local Network File Sharing</p>
          </div>
          <div className="flex items-center space-x-3 bg-white px-4 py-2 rounded-xl border border-slate-200 shadow-sm">
            <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-sm font-medium text-slate-700">{deviceName} (Self)</span>
          </div>
        </header>

        {activeTab === 'send' && (
          <SendPanel 
            onSend={handleSendFile} 
            selectedPeer={selectedPeer} 
            setSelectedPeer={setSelectedPeer}
            peers={peers}
            currentTransfer={currentTransfer}
            throttle={throttle}
            setThrottle={setThrottle}
          />
        )}

        {activeTab === 'receivers' && (
          <ReceiversPanel 
            peers={peers} 
            isScanning={isScanning} 
            onScan={handleScan}
            onSelect={(p) => {
              setSelectedPeer(p);
              setActiveTab('send');
            }}
          />
        )}

        {activeTab === 'history' && (
          <HistoryPanel />
        )}
      </main>

      {showSummary && (
        <Modal 
          isOpen={!!showSummary} 
          onClose={() => setShowSummary(null)}
          title={showSummary.status === 'success' ? "Transfer Complete!" : "Transfer Failed"}
        >
          <div className="space-y-4">
            <div className={`p-4 rounded-xl flex items-center space-x-4 ${showSummary.status === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
              <div className="flex-1">
                <p className="font-semibold">{showSummary.fileName}</p>
                <p className="text-sm opacity-80">{showSummary.fileSize}</p>
              </div>
              <div className="text-right">
                <p className="text-xs uppercase font-bold tracking-wider">Duration</p>
                <p className="font-mono">{showSummary.duration}</p>
              </div>
            </div>
            <button 
              onClick={() => setShowSummary(null)}
              className="w-full py-3 bg-slate-800 text-white rounded-xl font-medium hover:bg-slate-900 transition-colors"
            >
              Close
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default App;
