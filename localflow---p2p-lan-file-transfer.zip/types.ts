
export interface Peer {
  id: string;
  name: string;
  ip: string;
  status: 'online' | 'busy' | 'offline';
  isSelf?: boolean;
}

export interface TransferProgress {
  fileId: string;
  fileName: string;
  fileSize: number;
  progress: number; // 0 to 100
  speed: number; // bytes per second
  eta: number; // seconds
  status: 'waiting' | 'sending' | 'receiving' | 'completed' | 'failed';
  error?: string;
  startTime?: number;
}

export type ThrottlingLimit = 1 | 10 | 20 | 50 | 0; // 0 for unlimited (MB/s)

export interface TransferSummary {
  fileName: string;
  fileSize: string;
  duration: string;
  status: 'success' | 'error';
}
