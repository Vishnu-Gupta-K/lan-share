
import React from 'react';

const HistoryPanel: React.FC = () => {
  // In a production app, this would be persisted to local storage
  const mockHistory = [
    { id: 1, name: 'Project_Assets.zip', size: '1.2 GB', date: '2 mins ago', type: 'Sent', target: 'Design-Workstation', status: 'Success' },
    { id: 2, name: 'README.md', size: '14 KB', date: '15 mins ago', type: 'Received', target: 'MacBook-Pro', status: 'Success' },
    { id: 3, name: 'Draft_Video.mp4', size: '450 MB', date: '1 hour ago', type: 'Sent', target: 'Office-PC', status: 'Success' },
  ];

  return (
    <div className="max-w-5xl mx-auto">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">Transfer History</h2>
      
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">File Name</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Type</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Device</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Size</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Date</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {mockHistory.map((item) => (
              <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center">
                      <svg className="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                      </svg>
                    </div>
                    <span className="font-semibold text-slate-800">{item.name}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                    item.type === 'Sent' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'
                  }`}>
                    {item.type}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">{item.target}</td>
                <td className="px-6 py-4 text-sm text-slate-500 font-mono">{item.size}</td>
                <td className="px-6 py-4 text-sm text-slate-500">{item.date}</td>
                <td className="px-6 py-4 text-right">
                  <span className="text-green-500 font-bold text-sm">Success</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default HistoryPanel;
