
import React from 'react';
import { Peer } from '../types';

interface ReceiversPanelProps {
  peers: Peer[];
  isScanning: boolean;
  onScan: () => void;
  onSelect: (peer: Peer) => void;
}

const ReceiversPanel: React.FC<ReceiversPanelProps> = ({ peers, isScanning, onScan, onSelect }) => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Available Receivers</h2>
        <button 
          onClick={onScan}
          disabled={isScanning}
          className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
            isScanning 
            ? 'bg-indigo-100 text-indigo-400 cursor-not-allowed' 
            : 'bg-white text-indigo-600 border border-indigo-200 hover:bg-indigo-50 shadow-sm'
          }`}
        >
          <svg className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          <span>{isScanning ? 'Scanning LAN...' : 'Refresh List'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {peers.filter(p => !p.isSelf).length === 0 && !isScanning ? (
          <div className="col-span-full py-20 text-center bg-white border border-dashed border-slate-300 rounded-3xl">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-10 h-10 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <p className="text-slate-500 font-medium">No other devices found on your network.</p>
            <p className="text-sm text-slate-400 mt-1">Make sure other computers have LocalFlow open.</p>
            <button 
              onClick={onScan}
              className="mt-6 text-indigo-600 font-bold hover:underline"
            >
              Start New Scan
            </button>
          </div>
        ) : (
          <>
            {peers.filter(p => !p.isSelf).map((peer) => (
              <div 
                key={peer.id}
                className="group bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-md hover:border-indigo-200 transition-all cursor-pointer relative overflow-hidden"
                onClick={() => onSelect(peer)}
              >
                <div className="absolute top-0 right-0 p-4">
                  <span className="flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                  </span>
                </div>

                <div className="w-14 h-14 bg-indigo-50 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-indigo-600 transition-colors">
                  <svg className="w-8 h-8 text-indigo-500 group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>

                <h3 className="text-lg font-bold text-slate-800 mb-1">{peer.name}</h3>
                <p className="text-sm text-slate-500 font-mono mb-4">{peer.ip}</p>
                
                <div className="flex items-center justify-between mt-auto">
                  <span className="text-xs font-bold text-green-600 bg-green-50 px-3 py-1 rounded-full uppercase tracking-wider">Ready</span>
                  <div className="text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                </div>
              </div>
            ))}
            
            {isScanning && (
              <div className="bg-slate-50 border border-slate-200 p-6 rounded-3xl flex flex-col items-center justify-center space-y-4 animate-pulse">
                <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
                <p className="text-xs font-bold text-indigo-400 uppercase tracking-widest">Searching...</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default ReceiversPanel;
