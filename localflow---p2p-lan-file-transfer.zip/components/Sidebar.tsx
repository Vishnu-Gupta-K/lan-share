
import React from 'react';

interface SidebarProps {
  activeTab: 'send' | 'receivers' | 'history';
  setActiveTab: (tab: 'send' | 'receivers' | 'history') => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'send', label: 'Send Files', icon: 'M12 19l9 2-9-18-9 18 9-2zm0 0v-8' },
    { id: 'receivers', label: 'Receivers', icon: 'M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z' },
    { id: 'history', label: 'History', icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z' },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col p-4">
      <div className="flex items-center space-x-3 px-4 py-6 mb-4">
        <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
          </svg>
        </div>
        <span className="text-xl font-bold tracking-tight text-slate-800">LocalFlow</span>
      </div>

      <nav className="flex-1 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id as any)}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${
              activeTab === item.id 
              ? 'bg-indigo-50 text-indigo-700' 
              : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
            </svg>
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="mt-auto p-4 bg-slate-50 rounded-2xl">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest mb-1">Status</p>
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-green-500"></span>
          <span className="text-sm font-medium text-slate-600">Local Only Network</span>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
