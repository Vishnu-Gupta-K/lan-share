
import React, { useState, useRef } from 'react';
import { Peer, TransferProgress, ThrottlingLimit } from '../types';

interface SendPanelProps {
  onSend: (file: File, peerId: string) => void;
  selectedPeer: Peer | null;
  setSelectedPeer: (peer: Peer | null) => void;
  peers: Peer[];
  currentTransfer: TransferProgress | null;
  throttle: ThrottlingLimit;
  setThrottle: (limit: ThrottlingLimit) => void;
}

const SendPanel: React.FC<SendPanelProps> = ({ 
  onSend, 
  selectedPeer, 
  setSelectedPeer, 
  peers, 
  currentTransfer,
  throttle,
  setThrottle
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [manualIp, setManualIp] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSend = () => {
    if (file && selectedPeer) {
      onSend(file, selectedPeer.id);
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl">
      <div className="space-y-8">
        {/* Step 1: File Selection */}
        <section className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
            <span className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-sm mr-3 font-bold">1</span>
            Select File
          </h2>
          
          <div 
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center cursor-pointer transition-colors ${
              file ? 'border-green-300 bg-green-50' : 'border-slate-200 hover:border-indigo-400 hover:bg-slate-50'
            }`}
          >
            <input 
              type="file" 
              className="hidden" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
            />
            {file ? (
              <div className="text-center">
                <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-4 border border-green-200">
                  <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <p className="font-semibold text-slate-800 truncate max-w-xs">{file.name}</p>
                <p className="text-sm text-slate-500 mt-1">{formatSize(file.size)}</p>
                <button 
                  onClick={(e) => { e.stopPropagation(); setFile(null); }}
                  className="mt-4 text-xs font-bold text-red-500 uppercase tracking-wider hover:underline"
                >
                  Change File
                </button>
              </div>
            ) : (
              <>
                <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center mb-4">
                  <svg className="w-8 h-8 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                  </svg>
                </div>
                <p className="font-medium text-slate-700">Click to upload or drag & drop</p>
                <p className="text-sm text-slate-400 mt-1">Maximum file size recommended: 2GB</p>
              </>
            )}
          </div>
        </section>

        {/* Bandwidth Control */}
        <section className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
            <svg className="w-5 h-5 mr-3 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            Bandwidth Throttling
          </h2>
          <div className="grid grid-cols-5 gap-2">
            {[1, 10, 20, 50, 0].map((limit) => (
              <button
                key={limit}
                onClick={() => setThrottle(limit as ThrottlingLimit)}
                className={`py-2 px-1 rounded-lg text-xs font-bold transition-all ${
                  throttle === limit 
                  ? 'bg-amber-100 text-amber-700 border border-amber-300' 
                  : 'bg-slate-50 text-slate-500 border border-transparent hover:bg-slate-100'
                }`}
              >
                {limit === 0 ? 'UNLIMITED' : `${limit} MB/s`}
              </button>
            ))}
          </div>
        </section>
      </div>

      <div className="space-y-8">
        {/* Step 2: Target Selection */}
        <section className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm h-full flex flex-col">
          <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center">
            <span className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-sm mr-3 font-bold">2</span>
            Choose Receiver
          </h2>

          <div className="mb-4">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Or enter target IP address manually..." 
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none text-sm"
                value={manualIp}
                onChange={(e) => setManualIp(e.target.value)}
              />
              <svg className="w-4 h-4 text-slate-400 absolute left-4 top-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
              </svg>
            </div>
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto max-h-[300px] pr-2 custom-scrollbar">
            {peers.filter(p => !p.isSelf).length > 0 ? (
              peers.filter(p => !p.isSelf).map((peer) => (
                <button
                  key={peer.id}
                  onClick={() => setSelectedPeer(peer)}
                  className={`w-full flex items-center p-4 rounded-xl border transition-all ${
                    selectedPeer?.id === peer.id 
                    ? 'border-indigo-500 bg-indigo-50 ring-1 ring-indigo-500' 
                    : 'border-slate-100 bg-slate-50 hover:bg-slate-100 hover:border-slate-200'
                  }`}
                >
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm border border-slate-200 mr-4">
                    <svg className="w-6 h-6 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div className="text-left">
                    <p className="font-semibold text-slate-800">{peer.name}</p>
                    <p className="text-xs text-slate-500">{peer.ip}</p>
                  </div>
                  <div className="ml-auto">
                    <span className="w-2.5 h-2.5 rounded-full bg-green-500 block"></span>
                  </div>
                </button>
              ))
            ) : (
              <div className="text-center py-12 text-slate-400">
                <p className="text-sm">No receivers found on network.</p>
                <p className="text-xs mt-1">Try refreshing the Receivers tab.</p>
              </div>
            )}
          </div>

          <div className="mt-8">
            {currentTransfer ? (
              <div className="bg-slate-50 p-6 rounded-2xl border border-indigo-100">
                <div className="flex justify-between text-sm mb-2">
                  <span className="font-semibold text-slate-700">Sending...</span>
                  <span className="text-indigo-600 font-bold">{Math.round(currentTransfer.progress)}%</span>
                </div>
                <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden mb-4">
                  <div 
                    className="bg-indigo-600 h-full transition-all duration-300 ease-out"
                    style={{ width: `${currentTransfer.progress}%` }}
                  ></div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-xs font-medium text-slate-500">
                  <div className="bg-white p-2 rounded-lg border border-slate-100 text-center">
                    <p className="text-slate-400 uppercase text-[10px] mb-0.5">Speed</p>
                    <p className="text-slate-800">{(currentTransfer.speed / (1024 * 1024)).toFixed(2)} MB/s</p>
                  </div>
                  <div className="bg-white p-2 rounded-lg border border-slate-100 text-center">
                    <p className="text-slate-400 uppercase text-[10px] mb-0.5">Remaining</p>
                    <p className="text-slate-800">{currentTransfer.eta}s</p>
                  </div>
                </div>
              </div>
            ) : (
              <button 
                disabled={!file || (!selectedPeer && !manualIp)}
                onClick={handleSend}
                className={`w-full py-4 rounded-xl font-bold text-white shadow-lg transition-all flex items-center justify-center space-x-3 ${
                  file && (selectedPeer || manualIp) 
                  ? 'bg-indigo-600 hover:bg-indigo-700 hover:-translate-y-0.5 shadow-indigo-200' 
                  : 'bg-slate-300 cursor-not-allowed'
                }`}
              >
                <span>Send File Now</span>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </button>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

export default SendPanel;
