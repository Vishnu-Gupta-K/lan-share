
# LocalFlow - LAN File Transfer

LocalFlow is a high-performance, P2P file sharing application designed specifically for local area networks. It uses **WebRTC DataChannels** for ultra-fast, direct device-to-device transfers and **Node.js** for discovery.

## How to run on two computers

### 1. Prerequisites
- Both computers must be on the same WiFi or Ethernet network.
- Node.js installed on at least one machine (the "Server").

### 2. Setup the Signaling Server
1. Copy the `server.js` file provided in this repository to a folder.
2. Run `npm init -y` and `npm install express socket.io`.
3. Run `node server.js`.
4. Take note of the IP address of this computer (e.g., `192.168.1.10`).

### 3. Launch the App
1. Open the React application on both computers.
2. Ensure the `transferService.ts` is configured to point to your Server IP.
3. Your devices will automatically appear in the **Receivers** tab.

## Performance Optimization
- **Direct P2P**: By using WebRTC, data never leaves your local network, ensuring speeds are limited only by your router and hardware.
- **Chunking**: Files are sliced into 64KB chunks to prevent memory overflow and allow for real-time throttling.
- **Throttling**: The app supports bandwidth limiting to prevent saturating the network for other users.

## Future Improvements
- **Folder Transfer**: Support for recursively sending entire directory structures.
- **E2E Encryption**: While local, adding a layer of TLS for the WebRTC channel would enhance security.
- **Mobile Support**: Fully responsive layout for sharing between phones and desktops.
