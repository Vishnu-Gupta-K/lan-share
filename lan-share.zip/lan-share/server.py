"""
LAN Share — Main Server
========================
FastAPI server that handles:
  - Serving the web UI
  - Receiving files from other instances
  - Proxying file sends to other instances
  - WebSocket for real-time progress
  - LAN discovery coordination

Run with:  python server.py [--port PORT]
"""

import argparse
import asyncio
import json
import logging
import os
import sys
import time
import tempfile
import shutil
from pathlib import Path
from typing import Dict, Optional

import httpx
import uvicorn
from fastapi import FastAPI, File, UploadFile, WebSocket, WebSocketDisconnect, Form, Query
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
from starlette.middleware.cors import CORSMiddleware

from discovery import DiscoveryService, get_local_ip, get_device_name
from transfer import ThrottledWriter, CHUNK_SIZE, SPEED_PRESETS, format_size

# ──────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────
DEFAULT_PORT = 8384
UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "received_files")
os.makedirs(UPLOAD_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)-20s | %(levelname)-7s | %(message)s",
)
logger = logging.getLogger("lan-share")

# Global state
discovery: Optional[DiscoveryService] = None
active_websockets: Dict[str, WebSocket] = {}
transfer_progress: Dict[str, dict] = {}  # transfer_id -> latest progress


# ──────────────────────────────────────────────
# Lifespan (startup / shutdown)
# ──────────────────────────────────────────────
@asynccontextmanager
async def lifespan(application: FastAPI):
    """Modern lifespan handler — replaces deprecated on_event."""
    global discovery
    discovery = DiscoveryService(app_port=application.state.port)
    await discovery.start()
    logger.info(f"LAN Share running at http://{get_local_ip()}:{application.state.port}")
    yield
    if discovery:
        await discovery.stop()


# ──────────────────────────────────────────────
# App Init
# ──────────────────────────────────────────────
app = FastAPI(title="LAN Share", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ──────────────────────────────────────────────
# Static Files
# ──────────────────────────────────────────────
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


# ──────────────────────────────────────────────
# Web UI
# ──────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def index():
    with open(os.path.join(STATIC_DIR, "index.html"), "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())


# ──────────────────────────────────────────────
# Info & Discovery Endpoints
# ──────────────────────────────────────────────
@app.get("/api/info")
async def get_info():
    """Return this instance's info."""
    return {
        "device_name": get_device_name(),
        "ip": get_local_ip(),
        "port": app.state.port,
    }


@app.get("/api/peers")
async def get_peers():
    """Return discovered LAN peers."""
    if discovery:
        return {"peers": discovery.get_peers()}
    return {"peers": []}


@app.get("/api/ping")
async def ping():
    """Simple endpoint so other instances can verify we're alive."""
    return {"status": "ok", "device": get_device_name(), "ip": get_local_ip()}


@app.get("/api/diagnose/{target_ip}")
async def diagnose(target_ip: str, target_port: int = DEFAULT_PORT):
    """
    Diagnose connectivity to a target machine.
    Checks ICMP reachability and HTTP reachability.
    """
    import subprocess
    results = {"target": f"{target_ip}:{target_port}", "checks": []}

    # Check 1: Can we reach the IP at all? (ICMP ping)
    try:
        proc = subprocess.run(
            ["ping", "-n", "1", "-w", "2000", target_ip],
            capture_output=True, text=True, timeout=5
        )
        icmp_ok = proc.returncode == 0
        results["checks"].append({
            "name": "ICMP Ping",
            "ok": icmp_ok,
            "detail": "Host is reachable" if icmp_ok else "Host not reachable (may be blocked by firewall or offline)"
        })
    except Exception as e:
        results["checks"].append({"name": "ICMP Ping", "ok": False, "detail": str(e)})

    # Check 2: Can we reach the HTTP server?
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(3.0)) as client:
            resp = await client.get(f"http://{target_ip}:{target_port}/api/ping")
            http_ok = resp.status_code == 200
            results["checks"].append({
                "name": f"HTTP {target_port}",
                "ok": http_ok,
                "detail": "LAN Share is responding" if http_ok else f"HTTP {resp.status_code}"
            })
    except httpx.ConnectError:
        results["checks"].append({
            "name": f"HTTP {target_port}",
            "ok": False,
            "detail": "Connection refused — LAN Share may not be running on that machine"
        })
    except httpx.TimeoutException:
        results["checks"].append({
            "name": f"HTTP {target_port}",
            "ok": False,
            "detail": "Timed out — port is likely blocked by Windows Firewall. Run setup_firewall.bat as Admin on the receiver."
        })
    except Exception as e:
        results["checks"].append({"name": f"HTTP {target_port}", "ok": False, "detail": str(e)})

    # Check 3: What network profile is active?
    try:
        proc = subprocess.run(
            ["powershell", "-Command",
             "Get-NetConnectionProfile | Select-Object -Property Name,NetworkCategory | ConvertTo-Json"],
            capture_output=True, text=True, timeout=5
        )
        if proc.returncode == 0:
            import json as _json
            profiles = _json.loads(proc.stdout)
            if isinstance(profiles, dict):
                profiles = [profiles]
            results["checks"].append({
                "name": "Network Profile",
                "ok": True,
                "detail": ", ".join(f"{p.get('Name','?')}: {p.get('NetworkCategory','?')}" for p in profiles)
            })
    except Exception:
        pass

    results["all_ok"] = all(c["ok"] for c in results["checks"])
    return results


# ──────────────────────────────────────────────
# File Receive Endpoint (this is called by OTHER instances)
# ──────────────────────────────────────────────
@app.post("/api/receive")
async def receive_file(
    file: UploadFile = File(...),
    sender_name: str = Form("Unknown"),
    sender_ip: str = Form("Unknown"),
    speed_limit: int = Form(0),
):
    """
    Receive a file from another LAN Share instance.
    Saves to the received_files/ directory.
    """
    file_name = file.filename or "untitled"
    safe_name = "".join(c for c in file_name if c.isalnum() or c in ".-_ ()").strip()
    if not safe_name:
        safe_name = "received_file"

    # Avoid overwriting: append timestamp if file exists
    dest_path = os.path.join(UPLOAD_DIR, safe_name)
    if os.path.exists(dest_path):
        name, ext = os.path.splitext(safe_name)
        safe_name = f"{name}_{int(time.time())}{ext}"
        dest_path = os.path.join(UPLOAD_DIR, safe_name)

    total_size = file.size or 0
    start_time = time.time()

    try:
        with open(dest_path, "wb") as f:
            bytes_received = 0
            while True:
                chunk = await file.read(CHUNK_SIZE)
                if not chunk:
                    break
                f.write(chunk)
                bytes_received += len(chunk)

        elapsed = round(time.time() - start_time, 2)
        logger.info(
            f"Received '{safe_name}' ({format_size(bytes_received)}) "
            f"from {sender_name} ({sender_ip}) in {elapsed}s"
        )

        # Notify connected WebSocket clients about the received file
        notification = json.dumps({
            "type": "file_received",
            "file_name": safe_name,
            "file_size": bytes_received,
            "sender_name": sender_name,
            "sender_ip": sender_ip,
            "elapsed": elapsed,
        })
        for ws in list(active_websockets.values()):
            try:
                await ws.send_text(notification)
            except Exception:
                pass

        return {
            "status": "ok",
            "file_name": safe_name,
            "bytes_received": bytes_received,
            "elapsed": elapsed,
        }

    except Exception as e:
        logger.error(f"Error receiving file: {e}")
        # Clean up partial file
        if os.path.exists(dest_path):
            os.remove(dest_path)
        return JSONResponse(status_code=500, content={"status": "error", "detail": str(e)})


# ──────────────────────────────────────────────
# File Send Endpoint (called by OUR frontend to send a file)
# ──────────────────────────────────────────────
@app.post("/api/send")
async def send_file(
    file: UploadFile = File(...),
    target_ip: str = Form(...),
    target_port: int = Form(DEFAULT_PORT),
    speed_limit: str = Form("unlimited"),
    transfer_id: str = Form(""),
):
    """
    Accept a file from our UI, then stream it to the target machine.
    Progress is reported via WebSocket using transfer_id.
    """
    file_name = file.filename or "untitled"
    total_size = file.size or 0
    speed_bytes = SPEED_PRESETS.get(speed_limit, 0)

    logger.info(
        f"Sending '{file_name}' ({format_size(total_size)}) "
        f"to {target_ip}:{target_port} [limit={speed_limit}]"
    )

    # ── Pre-check: verify the receiver is reachable (with retries) ──
    preflight_ok = False
    last_error = None
    for attempt in range(3):
        try:
            timeout_s = 5.0 + attempt * 3  # 5s, 8s, 11s
            async with httpx.AsyncClient(timeout=httpx.Timeout(timeout_s)) as check_client:
                ping_resp = await check_client.get(f"http://{target_ip}:{target_port}/api/ping")
                if ping_resp.status_code == 200:
                    preflight_ok = True
                    logger.info(f"Receiver at {target_ip}:{target_port} is reachable (attempt {attempt+1})")
                    break
                else:
                    last_error = f"Receiver returned HTTP {ping_resp.status_code}"
        except httpx.ConnectError as e:
            last_error = ("connect_error", str(e))
            logger.warning(f"Pre-flight attempt {attempt+1}: ConnectError to {target_ip}:{target_port}")
        except httpx.TimeoutException as e:
            last_error = ("timeout", str(e))
            logger.warning(f"Pre-flight attempt {attempt+1}: Timeout to {target_ip}:{target_port}")
        except Exception as e:
            last_error = ("other", str(e))
        if attempt < 2:
            await asyncio.sleep(1)

    if not preflight_ok:
        if isinstance(last_error, tuple) and last_error[0] == "connect_error":
            detail = (
                f"Cannot connect to {target_ip}:{target_port}. "
                f"Make sure LAN Share is running on the receiver and "
                f"the IP address is correct. Also check Windows Firewall."
            )
            return JSONResponse(status_code=502, content={"status": "error", "detail": detail})
        elif isinstance(last_error, tuple) and last_error[0] == "timeout":
            detail = (
                f"Connection to {target_ip}:{target_port} timed out after 3 attempts. "
                f"On the RECEIVER computer: 1) Run setup_firewall.bat as Administrator, "
                f"2) Make sure LAN Share server is running, "
                f"3) Check if your WiFi blocks device-to-device traffic (AP isolation)."
            )
            return JSONResponse(status_code=504, content={"status": "error", "detail": detail})
        else:
            detail = f"Receiver at {target_ip}:{target_port} is not responding: {last_error}"
            return JSONResponse(status_code=502, content={"status": "error", "detail": detail})

    # Save the uploaded file to a temp location first
    temp_dir = tempfile.mkdtemp()
    temp_path = os.path.join(temp_dir, file_name)

    try:
        with open(temp_path, "wb") as f:
            while True:
                chunk = await file.read(CHUNK_SIZE)
                if not chunk:
                    break
                f.write(chunk)

        actual_size = os.path.getsize(temp_path)
        if total_size == 0:
            total_size = actual_size

        # Now stream the file to the target with throttling + progress
        start_time = time.time()
        bytes_sent = 0

        url = f"http://{target_ip}:{target_port}/api/receive"

        async def progress_gen():
            """Generator that reads file in chunks with throttling."""
            nonlocal bytes_sent
            with open(temp_path, "rb") as f:
                while True:
                    chunk = f.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    bytes_sent += len(chunk)

                    # Throttling
                    if speed_bytes > 0:
                        elapsed = time.time() - start_time
                        expected = bytes_sent / speed_bytes
                        if elapsed < expected:
                            await asyncio.sleep(expected - elapsed)

                    # Report progress via WebSocket
                    elapsed = max(time.time() - start_time, 0.001)
                    speed = bytes_sent / elapsed
                    remaining = total_size - bytes_sent
                    eta = remaining / speed if speed > 0 else 0
                    percent = (bytes_sent / total_size * 100) if total_size > 0 else 0

                    progress = {
                        "type": "progress",
                        "transfer_id": transfer_id,
                        "bytes_sent": bytes_sent,
                        "total_bytes": total_size,
                        "percent": round(min(percent, 100), 1),
                        "speed": round(speed),
                        "eta_seconds": round(eta, 1),
                        "elapsed_seconds": round(elapsed, 1),
                    }
                    transfer_progress[transfer_id] = progress

                    # Send to all connected WebSockets
                    msg = json.dumps(progress)
                    for ws in list(active_websockets.values()):
                        try:
                            await ws.send_text(msg)
                        except Exception:
                            pass

                    yield chunk

        # Use httpx to stream the file to the target
        async with httpx.AsyncClient(timeout=httpx.Timeout(None)) as client:
            # We need to send as multipart form; httpx doesn't support async generators
            # for multipart, so we read and throttle, then send chunks.
            # Instead, we use a custom approach: read with throttle, collect, and send.
            # For large files, we send all at once after throttle-reading,
            # but report progress during the read phase.

            # Actually, let's send the file directly and track upload progress
            # We'll use a different approach: send the file and report progress

            # Simpler approach: read file with throttle + progress, then send
            chunks = []
            async for chunk in progress_gen():
                chunks.append(chunk)

            file_data = b"".join(chunks)

            response = await client.post(
                url,
                files={"file": (file_name, file_data)},
                data={
                    "sender_name": get_device_name(),
                    "sender_ip": get_local_ip(),
                    "speed_limit": str(speed_bytes),
                },
            )

        elapsed = round(time.time() - start_time, 2)

        if response.status_code == 200:
            result_data = response.json()

            # Send completion message
            completion = json.dumps({
                "type": "complete",
                "transfer_id": transfer_id,
                "file_name": file_name,
                "file_size": total_size,
                "elapsed": elapsed,
                "status": "ok",
            })
            for ws in list(active_websockets.values()):
                try:
                    await ws.send_text(completion)
                except Exception:
                    pass

            return {
                "status": "ok",
                "file_name": file_name,
                "file_size": total_size,
                "elapsed": elapsed,
            }
        else:
            raise Exception(f"Target returned HTTP {response.status_code}: {response.text}")

    except Exception as e:
        # Build a user-friendly error message
        err_str = str(e)
        if "ConnectError" in err_str or "connection" in err_str.lower():
            user_msg = (
                f"Could not connect to {target_ip}:{target_port}. "
                "Ensure LAN Share is running on the receiver and check the firewall."
            )
        elif "timeout" in err_str.lower():
            user_msg = f"Connection to {target_ip}:{target_port} timed out."
        else:
            user_msg = f"Transfer failed: {err_str}"

        logger.error(f"Send error: {e}")

        # Send error via WebSocket
        error_msg = json.dumps({
            "type": "error",
            "transfer_id": transfer_id,
            "message": user_msg,
        })
        for ws in list(active_websockets.values()):
            try:
                await ws.send_text(error_msg)
            except Exception:
                pass

        return JSONResponse(
            status_code=500,
            content={"status": "error", "detail": user_msg},
        )
    finally:
        # Clean up temp file
        shutil.rmtree(temp_dir, ignore_errors=True)
        transfer_progress.pop(transfer_id, None)


# ──────────────────────────────────────────────
# WebSocket for Real-time Updates
# ──────────────────────────────────────────────
@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    ws_id = str(id(ws))
    active_websockets[ws_id] = ws
    logger.info(f"WebSocket connected: {ws_id}")

    try:
        while True:
            # Keep connection alive; handle client messages if any
            data = await ws.receive_text()
            # Clients can request peer refresh
            if data == "refresh_peers":
                peers = discovery.get_peers() if discovery else []
                await ws.send_text(json.dumps({"type": "peers", "peers": peers}))
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        active_websockets.pop(ws_id, None)
        logger.info(f"WebSocket disconnected: {ws_id}")


# ──────────────────────────────────────────────
# Received Files Listing
# ──────────────────────────────────────────────
@app.get("/api/received")
async def list_received_files():
    """List files in the received_files directory."""
    files = []
    for fname in os.listdir(UPLOAD_DIR):
        fpath = os.path.join(UPLOAD_DIR, fname)
        if os.path.isfile(fpath):
            stat = os.stat(fpath)
            files.append({
                "name": fname,
                "size": stat.st_size,
                "size_formatted": format_size(stat.st_size),
                "modified": stat.st_mtime,
            })
    files.sort(key=lambda x: x["modified"], reverse=True)
    return {"files": files}


@app.get("/api/download/{filename}")
async def download_file(filename: str):
    """Download a received file."""
    fpath = os.path.join(UPLOAD_DIR, filename)
    if os.path.isfile(fpath):
        return FileResponse(fpath, filename=filename)
    return JSONResponse(status_code=404, content={"detail": "File not found"})


# ──────────────────────────────────────────────
# Entry Point
# ──────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="LAN Share — Local File Transfer")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="Server port")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="Bind address")
    args = parser.parse_args()

    app.state.port = args.port

    print(f"""
╔══════════════════════════════════════════════╗
║           🔗  LAN Share v1.0                 ║
╠══════════════════════════════════════════════╣
║  Device:  {get_device_name():<33} ║
║  Local:   http://{get_local_ip()}:{args.port:<19} ║
║  Files:   {UPLOAD_DIR:<33} ║
╚══════════════════════════════════════════════╝
    """)

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        log_level="info",
        access_log=False,
    )


if __name__ == "__main__":
    main()
