"""
File Transfer Module
====================
Handles chunked file upload/download with bandwidth throttling
and real-time progress reporting via WebSocket.
"""

import asyncio
import time
import os
import logging
from typing import Optional, Callable, Awaitable

logger = logging.getLogger("lan-share.transfer")

# Chunk size for reading/writing files (64 KB — good balance for LAN)
CHUNK_SIZE = 65536


class ThrottledWriter:
    """
    Writes data to a file with optional bandwidth throttling.
    Reports progress via a callback.
    """

    def __init__(
        self,
        file_path: str,
        total_size: int,
        speed_limit_bytes: int = 0,  # 0 = unlimited
        progress_callback: Optional[Callable[..., Awaitable]] = None,
    ):
        self.file_path = file_path
        self.total_size = total_size
        self.speed_limit = speed_limit_bytes
        self.progress_callback = progress_callback
        self.bytes_written = 0
        self.start_time = 0.0
        self._file = None

    async def open(self):
        """Open the target file for writing."""
        os.makedirs(os.path.dirname(self.file_path) or ".", exist_ok=True)
        self._file = open(self.file_path, "wb")
        self.start_time = time.time()
        self.bytes_written = 0

    async def write_chunk(self, chunk: bytes):
        """Write a chunk with throttling and progress reporting."""
        if not self._file:
            raise RuntimeError("File not opened")

        self._file.write(chunk)
        self.bytes_written += len(chunk)

        # Throttling: if we're writing faster than the limit, sleep
        if self.speed_limit > 0:
            elapsed = time.time() - self.start_time
            expected_time = self.bytes_written / self.speed_limit
            if elapsed < expected_time:
                await asyncio.sleep(expected_time - elapsed)

        # Report progress
        if self.progress_callback:
            await self.progress_callback(self._build_progress())

    def _build_progress(self) -> dict:
        """Build a progress report dictionary."""
        elapsed = max(time.time() - self.start_time, 0.001)
        speed = self.bytes_written / elapsed
        remaining_bytes = self.total_size - self.bytes_written
        eta = remaining_bytes / speed if speed > 0 else 0
        percent = (self.bytes_written / self.total_size * 100) if self.total_size > 0 else 0

        return {
            "type": "progress",
            "bytes_sent": self.bytes_written,
            "total_bytes": self.total_size,
            "percent": round(min(percent, 100), 1),
            "speed": round(speed),
            "eta_seconds": round(eta, 1),
            "elapsed_seconds": round(elapsed, 1),
        }

    async def close(self):
        """Close the file."""
        if self._file:
            self._file.close()
            self._file = None


class ThrottledReader:
    """
    Reads data from a file with optional bandwidth throttling.
    Reports progress via a callback.
    """

    def __init__(
        self,
        file_path: str,
        speed_limit_bytes: int = 0,
        progress_callback: Optional[Callable[..., Awaitable]] = None,
    ):
        self.file_path = file_path
        self.total_size = os.path.getsize(file_path)
        self.speed_limit = speed_limit_bytes
        self.progress_callback = progress_callback
        self.bytes_read = 0
        self.start_time = 0.0

    async def read_chunks(self):
        """Async generator that yields file chunks with throttling."""
        self.start_time = time.time()
        self.bytes_read = 0

        with open(self.file_path, "rb") as f:
            while True:
                chunk = f.read(CHUNK_SIZE)
                if not chunk:
                    break

                self.bytes_read += len(chunk)
                yield chunk

                # Throttling
                if self.speed_limit > 0:
                    elapsed = time.time() - self.start_time
                    expected_time = self.bytes_read / self.speed_limit
                    if elapsed < expected_time:
                        await asyncio.sleep(expected_time - elapsed)

                # Report progress
                if self.progress_callback:
                    await self.progress_callback(self._build_progress())

    def _build_progress(self) -> dict:
        """Build a progress report dictionary."""
        elapsed = max(time.time() - self.start_time, 0.001)
        speed = self.bytes_read / elapsed
        remaining = self.total_size - self.bytes_read
        eta = remaining / speed if speed > 0 else 0
        percent = (self.bytes_read / self.total_size * 100) if self.total_size > 0 else 0

        return {
            "type": "progress",
            "bytes_sent": self.bytes_read,
            "total_bytes": self.total_size,
            "percent": round(min(percent, 100), 1),
            "speed": round(speed),
            "eta_seconds": round(eta, 1),
            "elapsed_seconds": round(elapsed, 1),
        }


def format_size(size_bytes: int) -> str:
    """Format byte count to human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 ** 2:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 ** 3:
        return f"{size_bytes / 1024**2:.1f} MB"
    else:
        return f"{size_bytes / 1024**3:.2f} GB"


# Speed limit presets (in bytes/sec)
SPEED_PRESETS = {
    "unlimited": 0,
    "1mbps": 1 * 1024 * 1024,
    "10mbps": 10 * 1024 * 1024,
    "20mbps": 20 * 1024 * 1024,
    "50mbps": 50 * 1024 * 1024,
}
