# LAN Share — Local Network File Transfer

A fast, modern file sharing application for transferring files between computers on the same local network (LAN).

![Python](https://img.shields.io/badge/Python-3.9+-blue)
![FastAPI](https://img.shields.io/badge/FastAPI-0.104+-green)

---

## Features

- **Drag & Drop** file selection with instant transfer
- **Automatic LAN Discovery** — detects other LAN Share instances via UDP broadcast
- **Real-time Progress** — live progress bar, speed, ETA via WebSocket
- **Bandwidth Throttling** — 1 / 10 / 20 / 50 MB/s or unlimited
- **Professional UI** — clean, modern design with dark & light themes
- **Received Files** — browse and download files sent to your device
- **Error Handling** — retry dialog on transfer failure
- **Zero Configuration** — works out of the box on any LAN

---

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    Computer A (Sender)                    │
│  ┌──────────────┐    ┌──────────────┐   ┌─────────────┐ │
│  │   Web UI      │◄──►│  FastAPI      │◄─►│  UDP Disc.  │ │
│  │  (Browser)    │ WS │  Server       │   │  Broadcast  │ │
│  └──────────────┘    └───────┬──────┘   └──────┬──────┘ │
│                              │ HTTP POST        │ UDP    │
└──────────────────────────────┼──────────────────┼────────┘
                               │                  │
                    ═══════════╪══════════════════╪═══ LAN ═══
                               │                  │
┌──────────────────────────────┼──────────────────┼────────┐
│                    Computer B│(Receiver)         │        │
│  ┌──────────────┐    ┌───────▼──────┐   ┌──────▼──────┐ │
│  │   Web UI      │◄──►│  FastAPI      │◄─►│  UDP Disc.  │ │
│  │  (Browser)    │ WS │  Server       │   │  Listen     │ │
│  └──────────────┘    └──────────────┘   └─────────────┘ │
└──────────────────────────────────────────────────────────┘
```

Each computer runs one instance of LAN Share that acts as **both sender and receiver**.

### Tech Stack

| Component       | Technology                          |
|-----------------|-------------------------------------|
| Backend         | Python 3.9+ / FastAPI / Uvicorn     |
| File Transfer   | HTTP chunked upload with throttling |
| Progress        | WebSocket (real-time)               |
| LAN Discovery   | UDP broadcast (port 37020)          |
| Frontend        | Vanilla HTML/CSS/JS (no build step) |

---

## Quick Start

### Prerequisites

- **Python 3.9+** installed on both computers
- Both computers connected to the **same local network** (Wi-Fi or Ethernet)

### Step 1 — Install on Both Computers

```bash
# Clone or copy the lan-share folder to both machines

# Install dependencies
cd lan-share
pip install -r requirements.txt
```

### Step 2 — Run on Both Computers

```bash
python server.py
```

This starts the server on port **8384** by default. Open the URL shown in the terminal:

```
╔══════════════════════════════════════════════╗
║           🔗  LAN Share v1.0                 ║
╠══════════════════════════════════════════════╣
║  Device:  MY-LAPTOP                          ║
║  Local:   http://192.168.1.100:8384          ║
║  Files:   /path/to/lan-share/received_files  ║
╚══════════════════════════════════════════════╝
```

### Step 3 — Open in Browser

Navigate to `http://localhost:8384` on each computer.

### Step 4 — Send a File

**Option A — Auto Discovery:**
1. Click the **Receivers** tab
2. Other LAN Share instances will appear automatically
3. Click **Select** next to a receiver
4. Choose a file and click **Send File**

**Option B — Manual IP:**
1. On the **Send File** tab, select a file
2. Enter the other computer's IP address
3. Choose a bandwidth limit (optional)
4. Click **Send File**

### Custom Port

If port 8384 is in use:

```bash
python server.py --port 9000
```

> **Note:** Both instances must use the same port for auto-discovery to work,
> or you can enter the correct port manually.

---

## Firewall Note

If devices aren't discovering each other:

1. **Windows:** Allow Python through Windows Firewall (a prompt usually appears on first run)
2. **macOS:** Allow incoming connections when prompted
3. **Linux:** Ensure ports 8384 (TCP) and 37020 (UDP) are open

```bash
# Linux example
sudo ufw allow 8384/tcp
sudo ufw allow 37020/udp
```

---

## Project Structure

```
lan-share/
├── server.py           # FastAPI server — all HTTP/WS endpoints
├── discovery.py        # UDP broadcast LAN peer discovery
├── transfer.py         # Throttled file read/write with progress
├── requirements.txt    # Python dependencies
├── static/
│   ├── index.html      # Single-page web UI
│   ├── styles.css      # Modern CSS with dark/light themes
│   └── app.js          # Frontend application logic
├── received_files/     # Downloaded files land here
└── README.md           # This file
```

---

## Performance Notes

- **Chunk size:** 64 KB — optimized for LAN throughput without excessive overhead
- **No disk caching on receiver:** Files are written directly to disk as chunks arrive
- **Async I/O:** FastAPI + Uvicorn use Python's asyncio for non-blocking transfers
- **Minimal overhead:** No encryption, authentication, or compression to slow things down
- **WebSocket progress:** Near-instant UI updates without polling

### Throughput Expectations

| Network       | Typical Speed          |
|---------------|------------------------|
| Gigabit LAN   | 80–110 MB/s            |
| 100 Mbps LAN  | 10–12 MB/s             |
| Wi-Fi (5 GHz) | 20–60 MB/s             |
| Wi-Fi (2.4G)  | 3–8 MB/s               |

---

## Future Improvements

- **Multi-file / folder transfer** with zip-on-the-fly
- **Resume interrupted transfers** with byte-range support
- **End-to-end encryption** (optional toggle)
- **QR code pairing** for mobile devices
- **Transfer history** with persistent database
- **Desktop notifications** using system tray integration
- **Electron wrapper** for native desktop app experience
- **mDNS/Bonjour** as alternative discovery mechanism
- **Streaming transfer** (avoid buffering entire file in memory for HTTP send)

---

## License

MIT — Free for personal and commercial use.
