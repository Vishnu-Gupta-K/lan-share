/* ═══════════════════════════════════════════════════════
   LAN Share — Frontend Application Logic
   Handles file selection, sending, receiver discovery,
   WebSocket progress, and UI state management.
   ═══════════════════════════════════════════════════════ */

(function () {
    'use strict';

    // ─── State ───
    let selectedFile = null;
    let ws = null;
    let currentTransferId = '';
    let isTransferring = false;

    // ─── DOM References ───
    const $ = (sel) => document.querySelector(sel);
    const $$ = (sel) => document.querySelectorAll(sel);

    const dom = {
        // Top bar
        deviceName: $('#deviceName'),
        deviceIP: $('#deviceIP'),
        themeToggle: $('#themeToggle'),

        // Tabs
        tabs: $$('.tab'),
        tabContents: $$('.tab-content'),

        // Send form
        dropZone: $('#dropZone'),
        fileInput: $('#fileInput'),
        fileInfo: $('#fileInfo'),
        fileName: $('#fileName'),
        fileSize: $('#fileSize'),
        removeFile: $('#removeFile'),
        targetIP: $('#targetIP'),
        targetPort: $('#targetPort'),
        pickReceiver: $('#pickReceiver'),
        sendForm: $('#sendForm'),
        sendBtn: $('#sendBtn'),
        speedOptions: $$('.speed-option'),

        // Progress
        progressPanel: $('#progressPanel'),
        progressPercent: $('#progressPercent'),
        progressBarFill: $('#progressBarFill'),
        statSpeed: $('#statSpeed'),
        statTransferred: $('#statTransferred'),
        statETA: $('#statETA'),

        // Receivers
        refreshPeers: $('#refreshPeers'),
        receiversList: $('#receiversList'),

        // Received files
        receivedList: $('#receivedList'),

        // Dialogs
        successDialog: $('#successDialog'),
        dlgFileName: $('#dlgFileName'),
        dlgFileSize: $('#dlgFileSize'),
        dlgDuration: $('#dlgDuration'),
        dlgClose: $('#dlgClose'),
        errorDialog: $('#errorDialog'),
        dlgErrorMsg: $('#dlgErrorMsg'),
        dlgErrorClose: $('#dlgErrorClose'),
        dlgRetry: $('#dlgRetry'),

        // Toasts
        toastContainer: $('#toastContainer'),
    };


    // ─── Utilities ───
    function formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        return (bytes / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0) + ' ' + units[i];
    }

    function formatDuration(seconds) {
        if (seconds < 1) return '< 1s';
        if (seconds < 60) return Math.round(seconds) + 's';
        const m = Math.floor(seconds / 60);
        const s = Math.round(seconds % 60);
        return `${m}m ${s}s`;
    }

    function formatSpeed(bytesPerSec) {
        return formatBytes(bytesPerSec) + '/s';
    }

    function generateId() {
        return 'tx_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
    }


    // ─── Theme Toggle ───
    function initTheme() {
        const saved = localStorage.getItem('lan-share-theme') || 'dark';
        document.documentElement.setAttribute('data-theme', saved);
    }

    dom.themeToggle.addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('lan-share-theme', next);
    });


    // ─── Tabs ───
    dom.tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const target = tab.dataset.tab;

            dom.tabs.forEach(t => t.classList.remove('active'));
            dom.tabContents.forEach(tc => tc.classList.remove('active'));

            tab.classList.add('active');
            document.getElementById('tab-' + target).classList.add('active');

            // Load data when switching tabs
            if (target === 'receivers') loadPeers();
            if (target === 'received') loadReceivedFiles();
        });
    });


    // ─── Device Info ───
    async function loadDeviceInfo() {
        try {
            const res = await fetch('/api/info');
            const data = await res.json();
            dom.deviceName.textContent = data.device_name;
            dom.deviceIP.textContent = data.ip + ':' + data.port;
        } catch (e) {
            dom.deviceName.textContent = 'Offline';
        }
    }


    // ─── WebSocket ───
    function connectWebSocket() {
        const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
        ws = new WebSocket(`${proto}//${location.host}/ws`);

        ws.onopen = () => {
            console.log('WebSocket connected');
        };

        ws.onmessage = (event) => {
            try {
                const msg = JSON.parse(event.data);
                handleWSMessage(msg);
            } catch (e) {
                console.error('WS parse error', e);
            }
        };

        ws.onclose = () => {
            console.log('WebSocket closed, reconnecting in 2s...');
            setTimeout(connectWebSocket, 2000);
        };

        ws.onerror = () => {
            ws.close();
        };
    }

    function handleWSMessage(msg) {
        switch (msg.type) {
            case 'progress':
                if (msg.transfer_id === currentTransferId) {
                    updateProgress(msg);
                }
                break;
            case 'complete':
                if (msg.transfer_id === currentTransferId) {
                    showSuccessDialog(msg);
                }
                break;
            case 'error':
                if (msg.transfer_id === currentTransferId) {
                    showErrorDialog(msg.message);
                }
                break;
            case 'file_received':
                showFileReceivedToast(msg);
                break;
            case 'peers':
                renderPeers(msg.peers);
                break;
        }
    }


    // ─── File Selection ───
    // Drag and drop
    dom.dropZone.addEventListener('click', () => dom.fileInput.click());

    dom.dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dom.dropZone.classList.add('drag-over');
    });

    dom.dropZone.addEventListener('dragleave', () => {
        dom.dropZone.classList.remove('drag-over');
    });

    dom.dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dom.dropZone.classList.remove('drag-over');
        if (e.dataTransfer.files.length > 0) {
            selectFile(e.dataTransfer.files[0]);
        }
    });

    dom.fileInput.addEventListener('change', () => {
        if (dom.fileInput.files.length > 0) {
            selectFile(dom.fileInput.files[0]);
        }
    });

    dom.removeFile.addEventListener('click', () => {
        clearFile();
    });

    function selectFile(file) {
        selectedFile = file;
        dom.fileName.textContent = file.name;
        dom.fileSize.textContent = formatBytes(file.size);
        dom.dropZone.classList.add('hidden');
        dom.fileInfo.classList.remove('hidden');
        updateSendButton();
    }

    function clearFile() {
        selectedFile = null;
        dom.fileInput.value = '';
        dom.dropZone.classList.remove('hidden');
        dom.fileInfo.classList.add('hidden');
        updateSendButton();
    }

    function updateSendButton() {
        dom.sendBtn.disabled = !selectedFile || !dom.targetIP.value.trim() || isTransferring;
    }

    dom.targetIP.addEventListener('input', updateSendButton);


    // ─── Speed Options ───
    dom.speedOptions.forEach(opt => {
        opt.addEventListener('click', () => {
            dom.speedOptions.forEach(o => o.classList.remove('selected'));
            opt.classList.add('selected');
        });
    });

    function getSelectedSpeed() {
        const checked = document.querySelector('input[name="speedLimit"]:checked');
        return checked ? checked.value : 'unlimited';
    }


    // ─── Send File ───
    dom.sendForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!selectedFile || isTransferring) return;

        const targetIP = dom.targetIP.value.trim();
        const targetPort = dom.targetPort.value || '8384';
        const speedLimit = getSelectedSpeed();

        if (!targetIP) return;

        currentTransferId = generateId();
        isTransferring = true;
        updateSendButton();

        // Show progress panel
        dom.progressPanel.classList.remove('hidden');
        dom.sendBtn.classList.add('hidden');
        resetProgress();

        const formData = new FormData();
        formData.append('file', selectedFile);
        formData.append('target_ip', targetIP);
        formData.append('target_port', targetPort);
        formData.append('speed_limit', speedLimit);
        formData.append('transfer_id', currentTransferId);

        try {
            const res = await fetch('/api/send', {
                method: 'POST',
                body: formData,
            });

            const data = await res.json();

            if (!res.ok || data.status === 'error') {
                throw new Error(data.detail || 'Transfer failed');
            }

            // Success is handled via WebSocket 'complete' message
            // But if the WS message was already received, this is a no-op
            if (!document.querySelector('#successDialog:not(.hidden)')) {
                showSuccessDialog({
                    file_name: data.file_name,
                    file_size: data.file_size,
                    elapsed: data.elapsed,
                });
            }

        } catch (err) {
            showErrorDialog(err.message);
        }
    });

    function resetProgress() {
        dom.progressPercent.textContent = '0%';
        dom.progressBarFill.style.width = '0%';
        dom.statSpeed.textContent = '—';
        dom.statTransferred.textContent = '—';
        dom.statETA.textContent = '—';
    }

    function updateProgress(data) {
        dom.progressPercent.textContent = data.percent + '%';
        dom.progressBarFill.style.width = data.percent + '%';
        dom.statSpeed.textContent = formatSpeed(data.speed);
        dom.statTransferred.textContent = formatBytes(data.bytes_sent) + ' / ' + formatBytes(data.total_bytes);
        dom.statETA.textContent = formatDuration(data.eta_seconds);
    }

    function finishTransfer() {
        isTransferring = false;
        dom.progressPanel.classList.add('hidden');
        dom.sendBtn.classList.remove('hidden');
        clearFile();
        updateSendButton();
    }


    // ─── Success Dialog ───
    function showSuccessDialog(data) {
        dom.dlgFileName.textContent = data.file_name || '—';
        dom.dlgFileSize.textContent = formatBytes(data.file_size || 0);
        dom.dlgDuration.textContent = formatDuration(data.elapsed || 0);
        dom.successDialog.classList.remove('hidden');
        finishTransfer();
    }

    dom.dlgClose.addEventListener('click', () => {
        dom.successDialog.classList.add('hidden');
    });


    // ─── Error Dialog ───
    function showErrorDialog(message) {
        dom.dlgErrorMsg.textContent = message || 'An unknown error occurred.';
        dom.errorDialog.classList.remove('hidden');
        isTransferring = false;
        dom.progressPanel.classList.add('hidden');
        dom.sendBtn.classList.remove('hidden');
        updateSendButton();
    }

    dom.dlgErrorClose.addEventListener('click', () => {
        dom.errorDialog.classList.add('hidden');
        clearFile();
    });

    dom.dlgRetry.addEventListener('click', () => {
        dom.errorDialog.classList.add('hidden');
        // Re-submit the form if file is still selected
        if (selectedFile) {
            dom.sendForm.dispatchEvent(new Event('submit'));
        }
    });


    // ─── Receivers (Peer Discovery) ───
    async function loadPeers() {
        dom.refreshPeers.classList.add('scanning');

        try {
            const res = await fetch('/api/peers');
            const data = await res.json();
            renderPeers(data.peers || []);
        } catch (e) {
            renderPeers([]);
        }

        setTimeout(() => {
            dom.refreshPeers.classList.remove('scanning');
        }, 600);
    }

    function renderPeers(peers) {
        if (peers.length === 0) {
            dom.receiversList.innerHTML = `
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5">
                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                        <line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>
                    </svg>
                    <p>No receivers found on this network</p>
                    <p class="hint">Make sure LAN Share is running on another device on the same network</p>
                </div>
            `;
            return;
        }

        dom.receiversList.innerHTML = peers.map((peer, i) => `
            <div class="receiver-card" style="animation-delay: ${i * 60}ms" data-ip="${peer.ip}" data-port="${peer.port}">
                <div class="receiver-avatar">
                    <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                        <line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>
                    </svg>
                </div>
                <div class="receiver-info">
                    <div class="receiver-name">${escapeHtml(peer.device_name)}</div>
                    <div class="receiver-ip">${escapeHtml(peer.ip)}:${peer.port}</div>
                </div>
                <div class="receiver-status">
                    <span class="status-dot online"></span>
                    Ready
                </div>
                <button class="receiver-select-btn" onclick="window._selectReceiver('${peer.ip}', ${peer.port})">
                    Select
                </button>
            </div>
        `).join('');
    }

    // Global function for receiver selection (called from inline onclick)
    window._selectReceiver = function (ip, port) {
        dom.targetIP.value = ip;
        dom.targetPort.value = port;

        // Switch to send tab
        dom.tabs.forEach(t => t.classList.remove('active'));
        dom.tabContents.forEach(tc => tc.classList.remove('active'));
        document.querySelector('[data-tab="send"]').classList.add('active');
        document.getElementById('tab-send').classList.add('active');

        updateSendButton();

        // Highlight the IP input briefly
        dom.targetIP.style.borderColor = 'var(--success)';
        dom.targetIP.style.boxShadow = '0 0 0 3px var(--success-subtle)';
        setTimeout(() => {
            dom.targetIP.style.borderColor = '';
            dom.targetIP.style.boxShadow = '';
        }, 1500);
    };

    dom.refreshPeers.addEventListener('click', loadPeers);

    // Pick receiver button on send form
    dom.pickReceiver.addEventListener('click', () => {
        // Switch to receivers tab
        dom.tabs.forEach(t => t.classList.remove('active'));
        dom.tabContents.forEach(tc => tc.classList.remove('active'));
        document.querySelector('[data-tab="receivers"]').classList.add('active');
        document.getElementById('tab-receivers').classList.add('active');
        loadPeers();
    });

    // Auto-refresh peers every 5 seconds when on receivers tab
    setInterval(() => {
        if (document.getElementById('tab-receivers').classList.contains('active')) {
            // Silent refresh (no animation)
            fetch('/api/peers')
                .then(res => res.json())
                .then(data => renderPeers(data.peers || []))
                .catch(() => {});
        }
    }, 5000);


    // ─── Received Files ───
    async function loadReceivedFiles() {
        try {
            const res = await fetch('/api/received');
            const data = await res.json();
            renderReceivedFiles(data.files || []);
        } catch (e) {
            renderReceivedFiles([]);
        }
    }

    function renderReceivedFiles(files) {
        if (files.length === 0) {
            dom.receivedList.innerHTML = `
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                        <polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                    <p>No files received yet</p>
                    <p class="hint">Files sent to this device will appear here</p>
                </div>
            `;
            return;
        }

        dom.receivedList.innerHTML = files.map((file, i) => `
            <div class="received-file-card" style="animation-delay: ${i * 50}ms">
                <div class="received-file-icon">
                    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                        <polyline points="14 2 14 8 20 8"/>
                    </svg>
                </div>
                <div class="received-file-info">
                    <div class="received-file-name">${escapeHtml(file.name)}</div>
                    <div class="received-file-meta">${file.size_formatted}</div>
                </div>
                <div class="received-file-actions">
                    <a href="/api/download/${encodeURIComponent(file.name)}" class="btn btn-secondary btn-sm" download>
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                            <polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                        </svg>
                        Download
                    </a>
                </div>
            </div>
        `).join('');
    }


    // ─── File Received Toast ───
    function showFileReceivedToast(data) {
        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.innerHTML = `
            <div class="toast-icon">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
            </div>
            <div class="toast-content">
                <div class="toast-title">File Received</div>
                <div class="toast-msg">${escapeHtml(data.file_name)} (${formatBytes(data.file_size)}) from ${escapeHtml(data.sender_name)}</div>
            </div>
            <button class="toast-close" onclick="this.parentElement.classList.add('closing'); setTimeout(() => this.parentElement.remove(), 300)">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
            </button>
        `;
        dom.toastContainer.appendChild(toast);

        // Auto-remove after 8 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.classList.add('closing');
                setTimeout(() => toast.remove(), 300);
            }
        }, 8000);

        // Refresh received files if on that tab
        if (document.getElementById('tab-received').classList.contains('active')) {
            loadReceivedFiles();
        }
    }


    // ─── Helpers ───
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }


    // ─── Init ───
    initTheme();
    loadDeviceInfo();
    connectWebSocket();

    // Periodically refresh device info
    setInterval(loadDeviceInfo, 30000);

})();
