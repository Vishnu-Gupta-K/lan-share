"""
LAN Discovery Module
====================
Uses UDP broadcast to discover other instances of the app on the local network.
Each running instance periodically broadcasts its presence and listens for others.

Key design:
  - Listener runs in a DEDICATED THREAD with a blocking socket + timeout,
    so packets are never missed even when the asyncio loop is busy.
  - Broadcasts to BOTH 255.255.255.255 AND the subnet-specific broadcast
    address for maximum compatibility on Windows / macOS / Linux.
"""

import asyncio
import json
import socket
import struct
import time
import platform
import logging
import threading
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("lan-share.discovery")

# Discovery constants
DISCOVERY_PORT = 37020
BROADCAST_INTERVAL = 2        # seconds between broadcasts
PEER_TIMEOUT = 10             # seconds before considering a peer offline
APP_SIGNATURE = "LANSHARE_V1"


def get_local_ip() -> str:
    """Get the primary local IP address of this machine."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def get_subnet_broadcast(ip: str, prefix: int = 24) -> str:
    """Calculate the subnet broadcast address (e.g. 192.168.1.255 for /24)."""
    try:
        ip_int = struct.unpack("!I", socket.inet_aton(ip))[0]
        mask = (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF
        broadcast_int = ip_int | (~mask & 0xFFFFFFFF)
        return socket.inet_ntoa(struct.pack("!I", broadcast_int))
    except Exception:
        return "255.255.255.255"


def get_all_broadcast_addresses() -> List[str]:
    """Get all broadcast addresses to send to for maximum reach."""
    local_ip = get_local_ip()
    addresses = {"255.255.255.255"}
    for prefix in [24, 16]:
        addr = get_subnet_broadcast(local_ip, prefix)
        if addr != local_ip:
            addresses.add(addr)
    return list(addresses)


def get_device_name() -> str:
    """Get a friendly device name."""
    return platform.node() or "Unknown Device"


class PeerInfo:
    """Represents a discovered peer on the network."""

    def __init__(self, device_name: str, ip: str, port: int, last_seen: float):
        self.device_name = device_name
        self.ip = ip
        self.port = port
        self.last_seen = last_seen

    @property
    def is_online(self) -> bool:
        return (time.time() - self.last_seen) < PEER_TIMEOUT

    def to_dict(self) -> dict:
        return {
            "device_name": self.device_name,
            "ip": self.ip,
            "port": self.port,
            "online": self.is_online,
            "last_seen": self.last_seen,
        }


class DiscoveryService:
    """
    Manages UDP broadcast-based LAN peer discovery.
    Listener runs in a real OS thread so packets are never dropped.
    """

    def __init__(self, app_port: int):
        self.app_port = app_port
        self.local_ip = get_local_ip()
        self.device_name = get_device_name()
        self.peers: Dict[str, PeerInfo] = {}
        self._running = False
        self._listen_thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    def get_peers(self) -> list:
        """Return list of currently known online peers (excluding self)."""
        with self._lock:
            self._cleanup_stale_peers()
            return [
                p.to_dict() for p in self.peers.values()
                if p.is_online and p.ip != self.local_ip
            ]

    def _cleanup_stale_peers(self):
        """Remove peers that haven't been seen recently."""
        stale = [ip for ip, p in self.peers.items() if not p.is_online]
        for ip in stale:
            del self.peers[ip]

    def _create_broadcast_message(self) -> bytes:
        """Create the UDP broadcast payload."""
        msg = json.dumps({
            "sig": APP_SIGNATURE,
            "device": self.device_name,
            "ip": self.local_ip,
            "port": self.app_port,
        })
        return msg.encode("utf-8")

    def _parse_message(self, data: bytes) -> Optional[PeerInfo]:
        """Parse an incoming UDP broadcast."""
        try:
            msg = json.loads(data.decode("utf-8"))
            if msg.get("sig") != APP_SIGNATURE:
                return None
            return PeerInfo(
                device_name=msg["device"],
                ip=msg["ip"],
                port=msg["port"],
                last_seen=time.time(),
            )
        except (json.JSONDecodeError, KeyError, UnicodeDecodeError):
            return None

    # ── Lifecycle ──────────────────────────
    async def start(self):
        """Start the discovery service (broadcast + listen)."""
        self._running = True
        self.local_ip = get_local_ip()
        targets = get_all_broadcast_addresses()
        logger.info(
            f"Discovery starting — local IP: {self.local_ip}, "
            f"port: {self.app_port}, broadcast targets: {targets}"
        )

        # Listener in a real thread — never misses packets
        self._listen_thread = threading.Thread(
            target=self._listen_thread_func, daemon=True, name="udp-listener"
        )
        self._listen_thread.start()

        # Broadcaster as an asyncio task
        asyncio.create_task(self._broadcast_loop())

    async def stop(self):
        """Stop the discovery service."""
        self._running = False
        if self._listen_thread and self._listen_thread.is_alive():
            self._listen_thread.join(timeout=2)

    # ── Broadcast (asyncio) ────────────────
    async def _broadcast_loop(self):
        """Periodically broadcast our presence on the LAN."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        targets = get_all_broadcast_addresses()

        while self._running:
            try:
                message = self._create_broadcast_message()
                for target in targets:
                    try:
                        sock.sendto(message, (target, DISCOVERY_PORT))
                    except OSError as e:
                        logger.debug(f"Broadcast to {target} failed: {e}")
            except Exception as e:
                logger.debug(f"Broadcast error: {e}")

            await asyncio.sleep(BROADCAST_INTERVAL)

        sock.close()

    # ── Listener (dedicated thread) ────────
    def _listen_thread_func(self):
        """
        Listen for broadcasts in a dedicated thread with a BLOCKING socket.
        The socket has a 1-second timeout so we can check self._running.
        """
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        try:
            sock.bind(("0.0.0.0", DISCOVERY_PORT))
        except OSError as e:
            logger.error(f"Cannot bind discovery port {DISCOVERY_PORT}: {e}")
            logger.error("Is another LAN Share instance already running?")
            return

        # Blocking with timeout — the correct way to do it
        sock.settimeout(1.0)
        logger.info(f"Discovery listener bound to UDP 0.0.0.0:{DISCOVERY_PORT}")

        while self._running:
            try:
                data, addr = sock.recvfrom(4096)
                peer = self._parse_message(data)
                if peer and peer.ip != self.local_ip:
                    with self._lock:
                        is_new = peer.ip not in self.peers or not self.peers[peer.ip].is_online
                        self.peers[peer.ip] = peer
                        if is_new:
                            logger.info(f"Discovered peer: {peer.device_name} ({peer.ip}:{peer.port})")
            except socket.timeout:
                continue  # normal — just loop back and check _running
            except OSError as e:
                if self._running:
                    logger.debug(f"Listen error: {e}")
                    time.sleep(0.5)

        sock.close()
        logger.info("Discovery listener stopped")
